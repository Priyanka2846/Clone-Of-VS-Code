var express = require('express');
var router = express.Router();
var fs=(require("fs"))
var userModel=require("./users")

/* GET home page. */
router.get('/', function(req, res, next) {
  fs.readdir('./files',{withFileTypes:true}, function(err,files){
    res.render("index",{files});
  });
  
});

router.get('/filecreate',function(req,res,next){
  fs.writeFile(`./files/${req.query.filename}`,"",function(err){
    if (err)throw err;
    res.redirect("/")
  });
});


router.get('/foldercreate',function(req,res,next){
  fs.mkdir(`./files/${req.query.foldername}`,function(err){
    if (err)throw err;
    res.redirect("/")
  });
});

router.get('/file/:filename', function(req, res, next) {
  fs.readdir('./files',{withFileTypes:true}, function(err,files){
    fs.readFile(`./files/${req.params.filename}`,"utf-8",function(err,data){
      res.render("fileshow",{files,filename: req.params.filename,data});
    })
   
  });
  
});

// router.get('/file/:filename', function(req, res, next) {
//   res.render("fileshow",{files,filename: req.params.filename,data});
//     })


router.get('/file/delete/:filename', function(req, res, next) {
  fs.unlink(`./files/${req.params.filename}`, function(err){
    res.redirect("/");
  })
})
// --------------CRUD MONGODB------------------------------
// --------------CREATE-----------------------------
router.get("/create",async function(req,res){
  var user=await userModel.create({
    username:"priyanka",
    name:"ta",
    age:21,
    email:"tanvi@gmail.com"
  });
  res.send(user);
}); 

// -----------------READ----------------------
router.get('/getUsers',async(req,res,next)=>{
  const allusers=await userModel.find() 
  // const allusers=await userModel.findOne({username:'tanvi'}) 
  // array ke form sare database me save hua aa jata
  res.send(allusers)
})
// -------------------UPDATE------------------------
router.get('/updateuser',async(req,res,next)=>{
  await userModel.findOneAndUpdate({username:'tanvi'},{
    email:'pagal@gmail.com'},{new:true});
    res.send('user updated')
  })
  

// ---------------------DELETE----------------------
router.get('/deleteuser',async(req,res,next)=>{
  await userModel.findOneAndDelete({username:'tanvi'})
  res.send('user deleted')
})
module.exports=router;