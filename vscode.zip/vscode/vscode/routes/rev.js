// const express=require('express')
// const app= express()
// app.use(function(req,res,next){
//     console.log("hello from middleware")
//     next();
// })
// app.get("/pro",function(req,res){
//     res.send("hello from profile")

// })
// app.listen(3000)